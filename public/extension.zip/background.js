// Background script for ContextReader extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('ContextReader extension installed');
});
